package com.capgemini.sessiontwo;

import java.util.Scanner;

public class Excercise22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter 5 digit number: ");
		int num= sc.nextInt();
		int sum=0;
		sc.nextLine();
		if(num>=10000&&num<=99999) {
			while(num>0) {
				int n=num%10;
				sum+=n;
				num=num/10;
			}
			System.out.println("Sum of digits: "+sum);
			
		}else {
			System.out.println("Invalid number");
		}
		

	}

}
