package com.capgemini.sessiontwo;

import java.util.Scanner;

public class Excercise23 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		sc.nextLine();
		int i=1, j=1, k=1;
		
		for(k=1;k<n;k++) {
			int a=1,b=1;
			if(i<=n-1) {
			for(i=k;a<6&&i<=n;i++,a++) {
				if(i%2==1)
					System.out.print(i+" ");
			}
			k=j-1;
			}
		
		if(i<=n-1) {
			for(j=i-5;b<=6&&j<n;j++,b++) {
				if(j%2==0)
					System.out.print(j+" ");
			}
			k=j-1;
		}}
	}

}
