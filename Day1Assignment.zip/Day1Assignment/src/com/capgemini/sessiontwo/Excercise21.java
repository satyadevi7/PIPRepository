package com.capgemini.sessiontwo;

import java.util.Scanner;

public class Excercise21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] a = new int[3][3];
		int [][] b= new int [3][4];
		int [][] result= new int[3][4];
		int sum=0;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter Matrix A values: ");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				a[i][j]=sc.nextInt();
				sc.nextLine();
			}
			
		}
		System.out.println("enter Matrix B values: ");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 4; j++) {
				b[i][j]=sc.nextInt();
				sc.nextLine();
			}
			
		}
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 4; j++) {
				for(int k=0;k<3;k++) {
					sum=sum+a[i][k]*b[k][j];
					result[i][j]=sum;
					sum=0;
				}
			}
		}
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 4; j++) {
				 System.out.print(result[i][j]+"\t");
				 
			        System.out.print("\n");
			}
		
			}

	}

}
