package com.capgemini.com.sessionfour;

public class Call {
	private String typeofCall;
	private float duration;
	
	double calculate(double duration){
		return 0.0;
	}

}
