package com.capgemini.com.sessionfour;

public class MainClass {

	public static void main(String args[]) {
		dailyworker dw = new dailyworker(777, "Dhoni", 75);
		salariedworker sw = new salariedworker(933, "Satya", 100);
		double salaryforDaily=dw.compay(dw.Days);
		double salaryforSalierd=sw.compay(sw.hours);
		System.out.println("Salary of Salierd worker: "+salaryforSalierd);
		System.out.println("Salary of Daily worker: "+salaryforDaily);
		
	}
}
