package com.capgemini.com.sessionfour;

public class Player42 {

}
class Cricket_Player extends Player42{
	
}
class Football_Player extends Player42{
	
}
class Hockey_Player extends Player42{
	
}
