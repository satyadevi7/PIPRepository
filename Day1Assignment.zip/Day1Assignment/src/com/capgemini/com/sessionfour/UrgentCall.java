package com.capgemini.com.sessionfour;

public class UrgentCall extends Call {
	@Override
	double calculate(double duration) {
		return duration*5.5;
	}
	

}
