package com.capgemini.com.sessionfour;

public class OrdinaryCall extends Call {
	@Override
	double calculate(double duration) {
		return duration*4.5;
	}

}
