package com.capgemini.com.sessionfour;

public class Worker {
	String empname;
	int empid;

	Worker(int id, String name) {
		empid = id;
		empname = name;
	}

	void Display_EmpDetails() {

		System.out.println("Employee ID : " + empid);
		System.out.println("Employee name : " + empname);
	}
	double compay(int hours) {
		return 0.0;
	}

}

class dailyworker extends Worker {
	int Days;

	dailyworker(int id, String name, int No_Days) {
		super(id, name);
		Days = No_Days;
	}
     @Override
	double compay(int Days) {
		int perdaywage = 100;
		Display_EmpDetails();
		 return perdaywage * Days*60;
	}
}

class salariedworker extends Worker {
	int wageperhour = 50, hours;

	salariedworker(int id, String name, int No_hrs) {
		super(id, name);
		hours = No_hrs;
	}
@Override
	double compay(int hours) {
		Display_EmpDetails();
		return  wageperhour * hours;
	}
}


