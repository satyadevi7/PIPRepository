package com.capgemini.com.sessionfour;

public class Excercise41 {
	private int number;
	

}
