package com.capgemini.com.sessionfour;

public class Excercise411 extends Excercise41 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Excercise41 childClass= new Excercise41();
		//childClass.number=15;

	}

}
