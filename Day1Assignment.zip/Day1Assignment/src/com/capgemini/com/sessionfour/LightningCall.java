package com.capgemini.com.sessionfour;

public class LightningCall extends Call{
	@Override
	double calculate(double duration) {
		return duration*3.5;
	}

}
