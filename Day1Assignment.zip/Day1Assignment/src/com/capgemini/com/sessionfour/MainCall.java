package com.capgemini.com.sessionfour;

import java.util.Scanner;

public class MainCall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Choose Call 1. Urgent call 2.Lightning call 3. Ordinary ***CHARGES APPLY***");
		int choice= sc.nextInt();
		sc.nextLine();
		float duration=0;
		double rate=0;
		Call call=null;
		switch (choice) {
		case 1:System.out.println("Enter Duration: ");
		 duration=sc.nextFloat();
			call=new UrgentCall();
			rate=call.calculate(duration);
			System.out.println("Charges: "+rate);
			break;
		case 2:
			System.out.println("Enter Duration: ");
			 duration=sc.nextFloat();
			call= new LightningCall();
			rate=call.calculate(duration);
			System.out.println("Charges: "+rate);
			
			break;
		case 3:
			System.out.println("Enter Duration: ");
			 duration=sc.nextFloat();
			call = new OrdinaryCall();
			rate=call.calculate(duration);
			System.out.println("Charges: "+rate);
			break;

		default:
			System.out.println("Please enter a valid choice");
			break;
		}
		

	}

}
