package com.capgemini.sessionOne;

import java.util.Scanner;

public class Excercise13 {

	public static void main(String[] args) {
		int a[]= new int[3];
				Scanner sc = new  Scanner(System.in);
						System.out.println("Enter 3 values");
						for (int i = 0; i < a.length; i++) {
							a[i]=sc.nextInt();
							sc.nextLine();
						}
		for (int i = 0; i < a.length; i++) {
			if(a[i]==2)
				break;
			if(a[i]==1)
				continue;
			System.out.println(a[i]);
		}
	}
}
