package com.capgemini.sessionOne;

public class Excercise12 {
	public static void main(String[] args) {
		int a=10;
		int b=5;
		System.out.println((a<<2)+(b>>2));
		System.out.println((a>0)||(b>0));
		System.out.println((a+b+100)/100);
		System.out.println(a&b);
	}

}
