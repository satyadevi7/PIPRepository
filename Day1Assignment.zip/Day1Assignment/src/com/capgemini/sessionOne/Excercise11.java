package com.capgemini.sessionOne;

import java.util.Scanner;

public class Excercise11 {
	
	public double area(float height, float width) {
		return 0.5*height*width;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float height;
		float width;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter height of triangle: ");
		height=sc.nextFloat();
		System.out.println("Enter width of triangle: ");
		width=sc.nextFloat();
		Excercise11 day1= new Excercise11();
		double area=day1.area(height, width);
		System.out.println("Area: "+ area);

	}

}
