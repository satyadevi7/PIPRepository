package com.capgemini.sessionOne;

import java.util.Scanner;

public class Excercise14 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Maths marks: ");
		float maths= sc.nextFloat();
		System.out.println("Enter Hindi marks: ");
		float hindi= sc.nextFloat();
		System.out.println("Enter English marks: ");
		float english= sc.nextFloat();
		System.out.println("average marks: "+(maths+hindi+english)/3);
	}

}
