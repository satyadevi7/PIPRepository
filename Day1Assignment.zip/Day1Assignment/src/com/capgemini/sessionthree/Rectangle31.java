package com.capgemini.sessionthree;

public class Rectangle31 {
	double length;
	double height;
	String color;
	public void set_length(double length) {
		this.length=length;
	}
	public void set_height(double height) {
		this.height=height;
	}
	public void set_color(String color) {
		this.color=color;
	}
	public double area() {
		return length*height;
	}
	public static void main(String[] args) {
		Rectangle31 rect1= new Rectangle31();
		rect1.set_length(5);
		rect1.set_height(7.8);
		rect1.set_color("green");
		Rectangle31 rect2= new Rectangle31();
		rect2.set_length(5);
		rect2.set_height(5);
		rect2.set_color("green");
		if((rect1.area()==rect2.area())&&(rect1.color.equalsIgnoreCase(rect2.color))) {
			System.out.println("Matching Rectangles");
		}
		else {
			System.out.println("Non matching Rectangles");
		}
	}

}
