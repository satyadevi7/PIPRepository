package com.capgemini.sessionthree;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Excercise34 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter employee Id of Employee: ");
		String empId= sc.nextLine();
		System.out.println("Enter first name ");
		String firstName= sc.nextLine();
		System.out.println("Enter Last name");
		String lastName= sc.nextLine();
		System.out.println("Enter salary: ");
		double salary= sc.nextDouble();
		System.out.println("Enter DoB in format(DD-MM-YYYY): ");
		String dob= sc.next();
		
		System.out.println("Enter Doj in format(DD-MM-YYYY): ");
		String doj= sc.next();
		if(!validateEmpid(empId)) {
			System.out.println("Please Enter valid employee Id");
		}
		if(!validateName(firstName)) {
		System.out.println("Name must start with Capital Letter");	
		}
		if(!validateName(lastName)) {
			System.out.println("Name must start with Capital Letter");	
			}
		if(!validateSalary(salary)) {
			System.out.println("salary must be in range between 2000 and 50000");
		}
		if(!validateDate(dob)) {
			System.out.println("Date must in format DD-MM-YYYY");
		}
		if(!validateDate(doj)) {
			System.out.println("Date must in format DD-MM-YYYY");
		}
	
		
		

	}

	private static boolean validateDate(String dob) {
		// TODO Auto-generated method stub
		//Date date=null;
		SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-YYYY");
		sdf.setLenient(false);
		try {
			sdf.parse(dob.trim());
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			return false;
		}
		/*
		 * String regex = "^(1[0-2]|0[1-9])-(3[01]" + "|[12][0-9]|0[1-9])-[0-9]{4}$";
		 * Pattern pattern = Pattern.compile(regex); Matcher matcher =
		 * pattern.matcher((CharSequence)dob); return matcher.matches();
		 */
		return true;
	}

	private static boolean validateSalary(double salary) {
		// TODO Auto-generated method stub
		boolean flag= false;
		if(salary>=2000&&salary<=50000) {
			flag= true;
		}else {
			flag = false;
		}
		return flag;
		
	}

	private static boolean validateName(String firstName) {
		boolean flag= false;
		String regex="[A-Z]{1}[a-zA-Z]{2,}";
			Pattern p= Pattern.compile(regex);
			Matcher m= p.matcher(firstName);
			if(m.matches())
				flag=true;
			else 
				flag=false;
			return flag;
			
		
	}

	private static boolean validateEmpid(String empId) {
		boolean flag= false;
	String regex="^[0-9]{5}_[F|T]S$";
		Pattern p= Pattern.compile(regex);
		Matcher m= p.matcher(empId);
		if(m.matches())
			flag=true;
		else 
			flag=false;
		return flag;
		
	}

}
