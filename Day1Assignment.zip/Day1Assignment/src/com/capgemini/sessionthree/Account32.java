package com.capgemini.sessionthree;

import java.util.Scanner;

public class Account32 {
	String name;
	long accnt_num;
	double initial_amount;
	String address;
	String typeOfAccnt;
	
	

	public Account32(String name, long accnt_num, double initial_amount, String address, String typeOfAccnt) {
		super();
		this.name = name;
		this.accnt_num = accnt_num;
		this.initial_amount = initial_amount;
		this.address = address;
		this.typeOfAccnt = typeOfAccnt;
	}



	public Account32(String name, long accnt_num, double initial_amount) {
		super();
		this.name = name;
		this.accnt_num = accnt_num;
		this.initial_amount = initial_amount;
	}
	public double deposit(double amount) {
		this.initial_amount=this.initial_amount+amount;
		return initial_amount;
	}
	public double withdraw(double amount) {
		this.initial_amount=this.initial_amount-amount;
		return this.initial_amount;
	}
	public double get_balance() {
		return this.initial_amount;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter amount: ");
		double amount=sc.nextDouble();
		System.out.println("Account 1");
		Account32 accnt1= new Account32("Satya", 12345, 5000);
		System.out.println(accnt1.deposit(amount));
		System.out.println(accnt1.withdraw(amount));
		System.out.println(accnt1.get_balance());
		System.out.println();
		System.out.println("Account 2");
		Account32 accnt2= new Account32("Satya Devi", 5678, 30000, "abcd", "Savings");
		System.out.println(accnt2.deposit(amount));
		System.out.println(accnt2.withdraw(amount));
		System.out.println(accnt2.get_balance());
		
		

	}

}
