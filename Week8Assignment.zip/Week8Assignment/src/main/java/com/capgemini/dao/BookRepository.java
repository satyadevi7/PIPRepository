package com.capgemini.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.model.Book;


@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {
	@Query("from Book where bookId=:bookId ")
	Book getBookbyId(@PathParam("bookId")int bookId);
	
	@Modifying
	@Transactional
	@Query("UPDATE Book e SET  e.bookName=:bookName, e.author=:author, e.publisher=:publisher WHERE e.bookId = :bookId ")
	void updateBook(@PathParam("bookId") int bookId,@PathParam("bookName") String bookName, @PathParam("author")String author,@PathParam("publisher") String publisher);
	
	
}
