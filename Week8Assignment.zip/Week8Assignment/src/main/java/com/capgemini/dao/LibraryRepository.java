package com.capgemini.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.model.Library;
@Repository
public interface LibraryRepository extends JpaRepository<Library, Integer> {
	@Query("from Library where libraryId=:libraryId ")
	Library getLibrarybyId(@Param("libraryId")int libraryId);


	@Modifying
	@Transactional
	@Query("UPDATE Library l SET  l.libraryname=:libraryname, l.libraryId=:libraryId1 WHERE l.libraryId = :libraryId ")
	void updateLibrary(@Param("libraryId")int libraryId, @Param("libraryId1")int libraryId2, @Param("libraryname")String libraryname);

@Query("from Library")
	List<Library> findAllLibraries();

}
