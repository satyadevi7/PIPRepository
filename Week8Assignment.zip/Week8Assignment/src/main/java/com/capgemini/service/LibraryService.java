package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Book;
import com.capgemini.model.Library;

public interface LibraryService {

	List<Book> getAllBooks();

	String addBook(Book book);

	String updateBook(int bookId, Book book);

	Book getBookbyId(int bookId);

	String deleteBookbyId(int bookId);

	String addLib(Library library);

	List<Library> getAllLibraries();

	Library getLibrarybyId(int libraryId);

	String updateLibrary(int libraryId, Library library);

	String deleteLibrarybyId(int libraryId);

}
