package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.BookRepository;
import com.capgemini.dao.LibraryRepository;
import com.capgemini.model.Book;
import com.capgemini.model.Library;

@Service
public class LibraryServiceImpl implements LibraryService {
	
	@Autowired
	private BookRepository bookRepo;
	
	@Autowired
	private LibraryRepository libRepo;

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepo.findAll();
	}

	@Override
	public String addBook(Book book) {
		// TODO Auto-generated method stub
		Library lib= book.getLib();
		libRepo.save(lib);
		bookRepo.save(book);
		return "Book added succesfully";
	}

	@Override
	public String updateBook(int bookId,Book book) {
		// TODO Auto-generated method stub
		
		bookRepo.updateBook(bookId,book.getBookName(),book.getAuthor(),book.getPublisher());
		return "Updated Succesfully";
	}

	@Override
	public Book getBookbyId(int bookId) {
		// TODO Auto-generated method stub
		return bookRepo.getBookbyId(bookId);
	}

	@Override
	public String deleteBookbyId(int bookId) {
		// TODO Auto-generated method stub
		Book book=bookRepo.getBookbyId(bookId);
		if(book!=null) {
			bookRepo.deleteById(bookId);
			return "Deleted successfully";
		}
		else
		return "book with Id doesnot exixts";
	}

	@Override
	public String addLib(Library library) {
		// TODO Auto-generated method stub
		List<Book> books= library.getBooks();
		libRepo.save(library);
		for (Book book : books) {
			book.setLib(library);
			bookRepo.save(book);
			System.out.println(book);
		}
		
		return "Library  added succesfully";
		
	}

	@Override
	public List<Library> getAllLibraries() {
		// TODO Auto-generated method stub
		return libRepo.findAllLibraries();
	}

	@Override
	public Library getLibrarybyId(int libraryId) {
		// TODO Auto-generated method stub
		return libRepo.getLibrarybyId(libraryId);
	}

	@Override
	public String updateLibrary(int libraryId,Library library) {
		// TODO Auto-generated method stub
		if(libRepo.existsById(libraryId)) {
			libRepo.updateLibrary(libraryId,library.getLibraryId(),library.getLibraryname());
			return "updated Successfully";
		}else
			
		return "No id present with given Id";
	}

	@Override
	public String deleteLibrarybyId(int libraryId) {
		// TODO Auto-generated method stub
		if(libRepo.existsById(libraryId)) {
			libRepo.deleteById(libraryId);
			return "Deleted successfully";
		}
		else
		return "No id present with given Id";
	}

}
