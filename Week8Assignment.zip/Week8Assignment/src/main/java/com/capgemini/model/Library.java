package com.capgemini.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Library {
	@Id
	private int libraryId;
	private String libraryname;
	@OneToMany(mappedBy = "lib")

	private List<Book> books = new ArrayList<Book>();

	public Library() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Library(int libraryId, String libraryname) {
		super();
		this.libraryId = libraryId;
		this.libraryname = libraryname;

	}

	public int getLibraryId() {
		return libraryId;
	}

	public void setLibraryId(int libraryId) {
		this.libraryId = libraryId;
	}

	public String getLibraryname() {
		return libraryname;
	}

	public void setLibraryname(String libraryname) {
		this.libraryname = libraryname;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

}
