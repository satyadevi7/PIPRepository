package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.capgemini.model.Book;
import com.capgemini.model.Library;
import com.capgemini.service.LibraryService;

@RestController
public class LibraryController {
	
	@Autowired
	private LibraryService service;
	
	
	
	@GetMapping(value = "/books")
	public List<Book> getAllBooks(){
		return service.getAllBooks();
	}
	
	@PostMapping(value = "/addbook",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String addBook(@RequestBody Book book) {
		
		return service.addBook(book);
	}
	
	@PutMapping(value = "/updateBook/{bookId}")
	public String updateBook(@PathVariable int bookId,@RequestBody Book book) {
		return service.updateBook(bookId,book);
	}
	
	@GetMapping(value = "/getBookById/{bookId}")
	public Book getBookbyId(@PathVariable int bookId) {
		return service.getBookbyId(bookId);
		
	}
	
	@DeleteMapping(value = "/deletebyId/{bookId}")
	public String deleteBook(@PathVariable int bookId) {
		return service.deleteBookbyId(bookId);
	}
	
	@PostMapping(value = "/addLibrary")
	public String addLibrary(@RequestBody Library library) {
		return service.addLib(library);
	}
	
	@GetMapping (value = "/getLibraries")
	public List<Library> getAllLibraries(){
		return service.getAllLibraries();
	}
	
	@GetMapping(value = "/getLibrarybyId/{libraryId}")
	public Library getLibrarybyId(@PathVariable int libraryId ) {
		return service.getLibrarybyId(libraryId);
	}
	
	@PutMapping(value = "/updateLibrary/{libraryId}")
	public String updateLibrary(@PathVariable int libraryId, @RequestBody Library library ) {
		return service.updateLibrary(libraryId,library);
	}
	
	@DeleteMapping(value = "/deleteLibrary/{libraryId}")
	public String deleteLibrary(@PathVariable int libraryId) {
		return service.deleteLibrarybyId(libraryId);
	}

}
