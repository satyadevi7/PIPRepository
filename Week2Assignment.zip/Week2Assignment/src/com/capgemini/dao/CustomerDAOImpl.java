package com.capgemini.dao;

import com.capgemini.bean.Customer;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public double calculatebillonAmount(Customer customer) {
		// TODO Auto-generated method stub
		double bill=customer.getBill();
		double discount=(bill/100)*5;
		bill=bill-discount;
		customer.setBill(bill);
		return customer.getBill();
	}

	@Override
	public double calculateAmountonEmployee(Customer customer) {
		// TODO Auto-generated method stub
		double bill=customer.getBill();
		double discount=(bill*30)/100;
		bill=bill-discount;
		customer.setBill(bill);
		return customer.getBill();
	}

	@Override
	public double calculateBillonAffilate(Customer customer) {
		double bill=customer.getBill();
		double discount=(bill*10)/100;
		bill=bill-discount;
		customer.setBill(bill);
		return customer.getBill();
	}

	@Override
	public double calculateBillonCustomerForTwoYears(Customer customer) {
		double bill=customer.getBill();
		double discount=(bill*5)/100;
		bill=bill-discount;
		customer.setBill(bill);
		return customer.getBill();

	}

}
