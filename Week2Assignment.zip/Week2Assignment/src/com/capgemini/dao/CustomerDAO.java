package com.capgemini.dao;

import com.capgemini.bean.Customer;

public interface CustomerDAO {

	double calculatebillonAmount(Customer customer);

	double calculateAmountonEmployee(Customer customer);

	double calculateBillonAffilate(Customer customer);

	double calculateBillonCustomerForTwoYears(Customer customer);

}
