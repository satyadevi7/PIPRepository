package com.capgemini.bean;

public class Customer {
	private String category;
	private double bill;
	private String typeOfCustomer;
	
	public Customer(String category, double bill, String typeOfCustomer) {
		super();
		this.category = category;
		this.bill = bill;
		this.typeOfCustomer = typeOfCustomer;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getBill() {
		return bill;
	}
	public void setBill(double bill) {
		this.bill = bill;
	}
	
	

}
