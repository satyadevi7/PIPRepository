package com.capgemini.service;

import com.capgemini.bean.Customer;
import com.capgemini.dao.CustomerDAO;
import com.capgemini.dao.CustomerDAOImpl;

public class CustomerServiceImpl implements CustomerService {
	static CustomerDAO dao= new CustomerDAOImpl();

	@Override
	public boolean validateBill(double bill) {
		// TODO Auto-generated method stub
		if(bill<0) {
			System.out.println("please enter valid bill");
			return false;
		}
		return true;
	}


	@Override
	public double calculateBillonAmount(Customer customer) {
		// TODO Auto-generated method stub
		return dao.calculatebillonAmount(customer);
	}


	@Override
	public double calculateBillonEmployee(Customer customer) {
		// TODO Auto-generated method stub
		return dao.calculateAmountonEmployee(customer);
	}


	@Override
	public double calculateBillonAffilate(Customer customer) {
		// TODO Auto-generated method stub
		return dao.calculateBillonAffilate(customer);
	}


	@Override
	public double calculateBillonCustomerForTwoYears(Customer customer) {
		// TODO Auto-generated method stub
		return dao.calculateBillonCustomerForTwoYears(customer);
	}

}
