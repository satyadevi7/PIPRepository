package com.capgemini.service;

import com.capgemini.bean.Customer;

public interface CustomerService {

	boolean validateBill(double bill);

	

	double calculateBillonAmount(Customer customer);



	double calculateBillonEmployee(Customer customer);



	double calculateBillonAffilate(Customer customer);



	double calculateBillonCustomerForTwoYears(Customer customer);

}
