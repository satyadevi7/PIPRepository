package com.capgemini.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;

public class MainUI {
	static Scanner sc = new Scanner(System.in);
	static CustomerService service= new CustomerServiceImpl();

	public static void main(String[] args) {
		boolean flag = false;
		String ch=null;
		do {
		do {
			try {
				System.out.println("Welcome to Discount System");
				System.out.println("1. Grocery 2. Other");
				int choice = sc.nextInt();
				sc.nextLine();
				flag = true;
				Customer customer = null;
				switch (choice) {
				case 1:
					boolean flag3=false;
					double bill=0;
					double actualBill=0;
					do {
					try {
					System.out.print("Enter bill: $");
					//System.out.print("$");
					bill = sc.nextDouble();
					flag3=service.validateBill(bill);
					customer = new Customer("Grocery", bill, null);
					}catch (InputMismatchException e) {
						// TODO: handle exception
						System.out.println("Please enter valid bill");
					}
					}while(!flag3);
					actualBill=service.calculateBillonAmount(customer);
					System.out.println("Discounted bill: $"+actualBill);

					break;
				case 2:
					boolean flag1 = false;
					boolean flag4=false;
					do {
						try {
							System.out.println(
									"choose type of customer: 1.Employee 2.Affilate 3.Customer Since two years 4.New Customer");
							int choice1 = sc.nextInt();
							sc.nextLine();
							double bill1=0;
							do {
								try {
							System.out.print("Enter bill: $");
							bill1=sc.nextDouble();
							flag4=service.validateBill(bill1);
								}catch (InputMismatchException e) {
									// TODO: handle exception
									System.out.println("Please enter valid bill");
								}
								}while(!flag4);
							flag1 = true;
							switch (choice1) {
							case 1:
								customer=new Customer("other", bill1, "employee");
								actualBill=service.calculateBillonEmployee(customer);
								actualBill=service.calculateBillonAmount(customer);
								System.out.println("Discounted bill: $"+actualBill);

								break;
							case 2:
								customer=new Customer("other", bill1, "affiliate");
								actualBill=service.calculateBillonAffilate(customer);
								actualBill=service.calculateBillonAmount(customer);
								System.out.println("Discounted bill: $"+actualBill);
								break;
							case 3:
								customer=new Customer("other", bill1, "customerForTwoYears");
								actualBill=service.calculateBillonCustomerForTwoYears(customer);
								actualBill=service.calculateBillonAmount(customer);
								System.out.println("Discounted bill: $"+actualBill);

								break;
							case 4:
								customer=new Customer("other", bill1, "customer");
								actualBill=service.calculateBillonAmount(customer);
								System.out.println("Discounted bill: $"+actualBill);


								break;

							default:
								flag1=false;
								System.out.println("Please Enter choice 1,2,3,4");
								break;
							}
							break;
						} catch (InputMismatchException e) {
							sc.nextLine();
							flag1 = false;
							System.out.println("Enter digits only");
						}
					} while (!flag1);
					break;

				default:
					flag=false;
					System.out.println("Please enter choice 1 or 2");
					break;
				}
				System.out.println("Do you want to continue yes or no");
				ch=sc.next();
				if(ch.equalsIgnoreCase("no"))
				System.exit(0);
			} catch (InputMismatchException e) {
				sc.nextLine();
				flag = false;
				System.out.println("Enter digits only");
			}
		} while (!flag);
		}while(ch.equalsIgnoreCase("yes"));

	}

}
