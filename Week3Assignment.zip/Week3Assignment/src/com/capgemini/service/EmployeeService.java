package com.capgemini.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.Address;
import com.capgemini.bean.Employee;
import com.capgemini.dao.EmployeeDAO;
import com.capgemini.dao.IEmployeeDAO;
import com.capgemini.exception.EmployeeException;

public class EmployeeService implements IEmployeeService {
	public IEmployeeDAO dao = new EmployeeDAO();

	@Override
	public boolean validateEmployeeId(String employeeId) throws EmployeeException {
		boolean flag = false;
		String regex = "^[0-9]{5}_FS$";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(employeeId);
		if (!m.matches()) {

			throw new EmployeeException("Invalid Employee Id : must be in format '12345_FS'");
		} else
			flag = true;
		return flag;
	}

	@Override
	public boolean validateName(String firstName) throws EmployeeException {
		boolean flag = false;
		String regex = "[A-Z]{1}[a-zA-Z]{2,}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(firstName);
		if (!m.matches()) {
			throw new EmployeeException("Name must start with a capital letter and should contain only alphabets");

		} else
			flag = true;
		return flag;
	}

	@Override
	public boolean validateSalary(double salary) throws EmployeeException {
		// TODO Auto-generated method stub
		boolean flag = false;
		if ((salary > 20000.0) && (salary < 500000.0)) {
			flag = true;

		} else
			throw new EmployeeException("Invalid salary: salary must be between 20000 and 5Lakh");

		return flag;
	}

	@Override
	public boolean validateDate(LocalDate d) throws EmployeeException {
		// TODO Auto-generated method stub
		boolean flag = false;
		if ((d.getYear() - LocalDate.now().getYear() < 0)) {

			throw new EmployeeException("Date must be now or future");
		} else if (d.getYear() == LocalDate.now().getYear()) {
			if ((d.getMonth().getValue() - LocalDate.now().getMonth().getValue() < 0)) {
				throw new EmployeeException("Date must be now or future");
			} else if (d.getMonth().getValue() == LocalDate.now().getMonth().getValue()) {
				if (d.getDayOfMonth() - LocalDate.now().getDayOfMonth() < 0) {
					throw new EmployeeException("Date must be now or future");
				}

			} else
				flag = true;

		}

		else
			flag = true;
		return flag;
	}

	@Override
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return dao.addEmployee(employee);
	}

	@Override
	public List<Employee> sortById() {
		// TODO Auto-generated method stub
		List<Employee> employees = new ArrayList<Employee>();
		employees = dao.getEmployees();
		Collections.sort(employees);
		return employees;
	}

	@Override
	public List<Employee> sortByFirstName() {
		// TODO Auto-generated method stub
		List<Employee> employees = new ArrayList<Employee>();
		employees = dao.getEmployees();
		Comparator<Employee> employeesByName = new Comparator<Employee>() {

			@Override
			public int compare(Employee employee1, Employee employee2) {
				// TODO Auto-generated method stub
				if (employee1.getFirstName().compareTo(employee2.getFirstName()) < 0)
					return -1;
				if (employee1.getFirstName().compareTo(employee2.getFirstName()) > 0)
					return 1;
				else
					return 0;
			}
		};
		Collections.sort(employees, employeesByName);

		return employees;
	}

	@Override
	public List<Employee> sortByLastName() {
		List<Employee> employees = new ArrayList<Employee>();
		employees = dao.getEmployees();
		Comparator<Employee> employeesByLastName = new Comparator<Employee>() {

			@Override
			public int compare(Employee employee1, Employee employee2) {
				// TODO Auto-generated method stub
				if (employee1.getLastName().compareTo(employee2.getLastName()) < 0)
					return -1;
				if (employee1.getLastName().compareTo(employee2.getLastName()) > 0)
					return 1;
				else
					return 0;
			}
		};
		Collections.sort(employees, employeesByLastName);

		return employees;
	}

	@Override
	public List<Employee> sortBySalary() {
		List<Employee> employees = new ArrayList<Employee>();
		employees = dao.getEmployees();
		Comparator<Employee> employeesBySalary = new Comparator<Employee>() {

			@Override
			public int compare(Employee employee1, Employee employee2) {
				// TODO Auto-generated method stub
				if (employee1.getSalary() < employee2.getSalary())
					return -1;
				if (employee1.getSalary() < employee2.getSalary())
					return 1;
				else
					return 0;
			}
		};
		Collections.sort(employees, employeesBySalary);

		return employees;
	}

	@Override
	public List<Employee> sortByAddress() {
		
		
		  List<Employee> employees= new ArrayList<Employee>(); 
		  employees=dao.getEmployees();
		  Comparator<Employee> employeeByAddress= new Comparator<Employee>() {
		  
		  @Override public int compare(Employee o1, Employee o2)
		  { // TODO Auto-generated method stub 
			  Address[] a=o1.getAddress();
			  Address[] b=o2.getAddress();
			  int e=0;
			 for (Address ad1 : a) {
				 for (Address ad2 : b) {
					if(ad1.compareTo(ad2)<0)
						return -1;
					else if(ad1.compareTo(ad2)>0)
						return 1;
					else
						return 0;
				}
				
			}
				  
				  return 0; } };
		  
		 
		
		Collections.sort(employees,employeeByAddress);
		return employees;
	}

	@Override
	public List<Employee> sortByDepartment() {
		List<Employee> employees = new ArrayList<Employee>();
		employees = dao.getEmployees();
		Comparator<Employee> employeesByDepartment = new Comparator<Employee>() {

			@Override
			public int compare(Employee employee1, Employee employee2) {
				// TODO Auto-generated method stub
				if (employee1.getDepartment().compareTo(employee2.getDepartment()) < 0)
					return -1;
				if (employee1.getDepartment().compareTo(employee2.getDepartment()) > 0)
					return 1;
				else
					return 0;
			}
		};
		Collections.sort(employees, employeesByDepartment);

		return employees;
	}

}
