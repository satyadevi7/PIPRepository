package com.capgemini.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.capgemini.bean.Employee;
import com.capgemini.exception.EmployeeException;

public interface IEmployeeService {

	boolean validateEmployeeId(String employeeId) throws EmployeeException;

	boolean validateName(String firstName)throws EmployeeException;

	boolean validateSalary(double salary)throws EmployeeException;

	boolean validateDate(LocalDate d)throws EmployeeException;

	boolean addEmployee(Employee employee);

	List<Employee> sortById();

	List<Employee> sortByFirstName();

	List<Employee> sortByLastName();

	List<Employee> sortBySalary();

	List<Employee> sortByAddress();

	List<Employee> sortByDepartment();

}
