package com.capgemini.bean;

public class Address implements Comparable<Address> {
	private int addressId;
	private String adressLine1;
	private String city;
	private String state;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(int addressId, String adressLine1, String city, String state) {
		super();
		this.addressId = addressId;
		this.adressLine1 = adressLine1;
		this.city = city;
		this.state = state;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAdressLine1() {
		return adressLine1;
	}
	public void setAdressLine1(String adressLine1) {
		this.adressLine1 = adressLine1;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", adressLine1=" + adressLine1 + ", city=" + city + ", state="
				+ state + "]";
	}
	@Override
	public int compareTo(Address address) {
		if(this.addressId<address.getAddressId())
			return -1;
		if(this.addressId>address.getAddressId())
			return -1;
		else 
			return 0;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + addressId;
		result = prime * result + ((adressLine1 == null) ? 0 : adressLine1.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (addressId != other.addressId)
			return false;
		if (adressLine1 == null) {
			if (other.adressLine1 != null)
				return false;
		} else if (!adressLine1.equals(other.adressLine1))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		return true;
	}
	
	

}
