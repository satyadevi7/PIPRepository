package com.capgemini.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bean.Employee;

public class EmployeeDAO implements IEmployeeDAO {
	List<Employee> employees= new ArrayList<Employee>();

	@Override
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employees.add( employee);
		 return true;
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return employees;
	}

}
