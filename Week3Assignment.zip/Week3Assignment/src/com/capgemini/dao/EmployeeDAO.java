package com.capgemini.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bean.Address;
import com.capgemini.bean.Department;
import com.capgemini.bean.Employee;

public class EmployeeDAO implements IEmployeeDAO {
	List<Employee> employees= new ArrayList<Employee>();
	{
		Address[] address= {new Address(156, "abc", "kakinada", "Andra"),new Address(768, "mayura", "bangalore", "karnataka")};
		Address[] address2= {new Address(678, "efg", "devarpilli", "Andra"),new Address(856, "mayura", "bangalore", "karnataka")};
		employees.add(new Employee("78987_FS", "Satya", "Devi", 80000.0, LocalDate.of(2020, 9, 23), new Department(123, "FS", "Bangalore"), address));
		employees.add(new Employee("78678_FS", "Sana", "Laxmi", 40000.0, LocalDate.of(2020, 12, 8), new Department(123, "NON_FS", "Hyderabad"), address2));
	}

	@Override
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employees.add( employee);
		 return true;
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return employees;
	}

}
