package com.capgemini.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.bean.Employee;

public interface IEmployeeDAO {

	boolean addEmployee(Employee employee);
	List<Employee> getEmployees();

}
