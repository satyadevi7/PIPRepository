package com.capgemini.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bean.Address;
import com.capgemini.bean.Department;
import com.capgemini.bean.Employee;
import com.capgemini.exception.EmployeeException;
import com.capgemini.service.EmployeeService;
import com.capgemini.service.IEmployeeService;

public class MainUI {
	public static Scanner sc = new Scanner(System.in);
	public static IEmployeeService service = new EmployeeService();
	

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		String continue1 = null;
		try {
		System.out.println("Welcome");
		System.out.println("Enter count of employees: ");
		int count = sc.nextInt();
		sc.nextLine();
		
		for (int i = 0; i < count; i++) {

			String employeeId;
			boolean idflag = false;
			do {
				System.out.println("Enter employee Id: ");
				employeeId = sc.next();
				sc.nextLine();
				try {
					idflag = service.validateEmployeeId(employeeId);
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
			} while (!idflag);
			boolean nameFlag = false;
			String firstName;
			do {
				System.out.println("Enter first name: ");
				firstName = sc.nextLine();
				try {
					nameFlag = service.validateName(firstName);
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
			} while (!nameFlag);
			nameFlag = false;
			String lastName;
			do {
				System.out.println("Enter Last name: ");
				lastName = sc.nextLine();
				// sc.nextLine();
				try {
					nameFlag = service.validateName(lastName);
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
			} while (!nameFlag);
			boolean salaryFlag = false;
			double salary = 0;
			do {
				System.out.println("Enter salary: ");
				salary = sc.nextDouble();
				System.out.println(salary);
				// sc.nextLine();
				try {
					salaryFlag = service.validateSalary(salary);
					System.out.println(salaryFlag);
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}

			} while (!salaryFlag);
			String date;
			boolean dateFlag = false;
			LocalDate d;
			do {
				System.out.println("Enter date of Joining: ");
				date = sc.next();
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				Date date1 = sdf.parse(date);
				Calendar c = Calendar.getInstance();
				c.setTime(date1);
				d = LocalDate.of(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DATE));
				try {
					dateFlag = service.validateDate(d);
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
			} while (!dateFlag);
			System.out.println("Enter Department details: ");
			System.out.println("Enter department Id: ");
			int departmentId = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter department name: ");
			String departmentname = sc.nextLine();
			System.out.println("Enter location: ");
			String location = sc.nextLine();
			Department departmnt = new Department(departmentId, departmentname, location);
			System.out.println("Enter Permanent adress: ");
			System.out.println("Enter address Id");
			int addressId = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter adressLine1");
			String adressLine1 = sc.nextLine();
			System.out.println("Enter city: ");
			String city = sc.nextLine();
			System.out.println("Enter State: ");
			String state = sc.nextLine();
			Address permanentAddress = new Address(addressId, adressLine1, city, state);
			System.out.println("Enter present adress: ");
			System.out.println("Enter address Id");
			int addressId1 = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter adressLine1");
			String adressLine11 = sc.nextLine();
			System.out.println("Enter city: ");
			String city1 = sc.nextLine();
			System.out.println("Enter State: ");
			String state1 = sc.nextLine();
			Address presentAddress = new Address(addressId1, adressLine11, city1, state1);
			Address[] listOfAdress = new Address[2];
			listOfAdress[0]=permanentAddress;
			listOfAdress[1]=(presentAddress);
			Employee employee = new Employee(employeeId, firstName, lastName, salary, d, departmnt, listOfAdress);
			service.addEmployee(employee);
			System.out.println("Employee successfully created");

		}
		

		do {
			System.out.println("Select type of sort: ");

			System.out.println(
					"1.ByEmployeeId \n 2.ByFirstName \n 3.ByLastName \n 4.BySalary \n 5.ByAddress \n 6.ByDepartment");
			boolean f = false;
			do {
				try {
					System.out.println("Enter choice: ");
					int choice = sc.nextInt();
					sc.nextLine();
					f = true;
					switch (choice) {
					case 1:
						 List< Employee> employees= new ArrayList<Employee>();
						 employees=service.sortById();
						for (Employee employee : employees) {
							System.out.println(employee);
						}

						break;
					case 2:
						 List< Employee> employeesbyName= new ArrayList<Employee>();
						 employeesbyName=service.sortByFirstName();
						for (Employee employee : employeesbyName) {
							System.out.println(employee);
						}
						break;
					case 3:
						List< Employee> employeesbyLastName= new ArrayList<Employee>();
						employeesbyLastName=service.sortByLastName();
						for (Employee employee : employeesbyLastName) {
							System.out.println(employee);
						}
						break;
					case 4:
						List< Employee> employeesbySalary= new ArrayList<Employee>();
						employeesbySalary=service.sortBySalary();
						for (Employee employee : employeesbySalary) {
							System.out.println(employee);
						}
						
						break;
					case 5:
						List< Employee> employeesbyAddress= new ArrayList<Employee>();
						employeesbyAddress=service.sortByAddress();
						for (Employee employee : employeesbyAddress) {
							System.out.println(employee);
						}
						break;
					case 6:
						List< Employee> employeesbyDepartment= new ArrayList<Employee>();
						employeesbyDepartment=service.sortByDepartment();
						for (Employee employee : employeesbyDepartment) {
							System.out.println(employee);
						}
						break;

					default:
						System.out.println("enter 1-6 only");
						break;
					}

				} catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("Enter digits only");
				}
			} while (!f);
			System.out.println("Enter yes to continue: ");
			continue1 = sc.next();
			if (!continue1.equalsIgnoreCase("yes"))
				System.exit(0);
		} while (continue1.equalsIgnoreCase("yes"));
		}catch (InputMismatchException e) {
			// TODO: handle exception
			System.out.println("invalid");
		}
		sc.close();
		
	}
	

}
