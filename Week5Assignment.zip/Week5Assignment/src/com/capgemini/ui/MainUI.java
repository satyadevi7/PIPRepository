package com.capgemini.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.bean.Account;
import com.capgemini.bean.Loan;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.BankException;
import com.capgemini.service.BankServiceImpl;
import com.capgemini.service.IBankService;

public class MainUI {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		IBankService service= new BankServiceImpl();
		
		Transaction transaction = new Transaction();
		Loan loan = new Loan();
		int choice = 0;
		String cont = null;
		Loan loan1 = null;

		do {
			boolean choiceFlag = false;
			do {
				try {
					System.out.println("1. Create Account 2. Login");
					choice = sc.nextInt();
					sc.nextLine();
					switch (choice) {
					case 1:
						// Scanner sc = new Scanner(System.in);
						String accountName = null;
						String accountId = null;
						int i = 0;
						try {
							do {
								System.out.println("Account Name: ");
								accountName = sc.next();
							} while (!service.validateName(accountName));
						} catch (BankException e1) {
							System.out.println(e1.getMessage());
						}
						System.out.println("Address: ");
						String address = sc.next();
						//sc.nextLine();
						boolean amountFlag=false;
						double depositAmount;
						do {
						System.out.println("Enter deposit ammount: ");
						depositAmount = sc.nextDouble();
						
						try {
							amountFlag=service.validateamount(depositAmount);
						} catch (BankException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						}while(!amountFlag);
						/*
						 * do { System.out.println("Do u want Loan :(Yes or No)"); choice1=sc.next();
						 * if(choice1.equalsIgnoreCase("yes")) { do {
						 * System.out.println("Enter loan type: "); loanType=sc.next();
						 * }while(validateLoan(loanType)); System.out.println("Enter loan amount: ");
						 * loanAmount=sc.nextDouble(); String loanId=getAccountId();
						 * 
						 * }else { System.out.println("Plase enter yes or no"); }}
						 * while(choice1.equalsIgnoreCase("yes")||choice1.equalsIgnoreCase("no"));
						 */
						try {
							accountId = service.getAccountId();
							service.addAccount(new Account(accountId, accountName, address, depositAmount));
							System.out.println("Account created successfully with accountId: " + accountId);
							choiceFlag = true;
						} catch (BankException e1) {
							System.out.println(e1.getMessage());
						}
						
						break;
					case 2:
						String accntId = null;
						int choice2 = 0;
						
						try {
							do {
								System.out.println("Enter accountId: ");
								accntId = sc.next();
								
							} while (!service.validateaccntId(accntId));
							service.searchAccount(accntId);
							Account account= new Account(accntId);
							boolean choiceFlag3 = false;
							do {

								try {
									System.out.println("1. Account Details 2. Loan 3. Transaction");
									choice2 = sc.nextInt();
									sc.nextLine();
									choiceFlag3 = true;
									switch (choice2) {
									case 1:
										service.getAccount(account);
										//transaction.showDetails(acc1);
										break;
									case 2:
										boolean choiceFlag1 = false;
										int ch1 = 0;
										String loanId1 = null;
										do {
											try {
												System.out.println("1. Apply Loan 2. Pay loan ");
												ch1 = sc.nextInt();
												choiceFlag1 = true;

												switch (ch1) {
												case 1:
													boolean loanflag=false;
													String loanType;
													do {
														System.out.println("Enter loan type: "); loanType=sc.next();
														try {
															loanflag=service.validateLoan(loanType);
														}catch (BankException e) {
															System.out.println(e.getMessage());
														}
													}while(!loanflag);
													System.out.println("enter loan amount: ");
													double amount=sc.nextDouble();
													long accountNo = (long) (Math.random() * 10000000);
													String loanId = Long.toString(accountNo);
													loanId = loanId + "-ASDF";
													service.addLoan(account,new Loan(loanId, loanType, amount));
													System.out.println("Loan successfully sanctioned with loanId: "+loanId);
													
													break;
												case 2:
													boolean flag = false;
													do {
														try {
															System.out.println(" 1. Pay loan 2. Loan details ");
															int ch = sc.nextInt();
															// sc.nextLine();
															flag = true;
															

															
															switch (ch) {
															
															case 1:
																boolean loanIdFlag=false;
																
																try {
																System.out.println("Enter loan Id");
																loanId1 = sc.next();
																service.serachLoan(loanId1);
																System.out.println("Enter amount: ");
																double loanAmount1 = sc.nextDouble();
																service.payLoan(loanId1,loanAmount1);
																}catch (BankException e) {
																	// TODO: handle exception
																	System.out.println(e.getMessage());
																}
																
																//transaction.payLoan(loanAmount1, loanId1, loans);
																break;
															case 2:
																try {
																	System.out.println("Enter loan Id");
																	loanId1 = sc.next();
																	service.serachLoan(loanId1);
																	service.getLoan(loanId1);
																	}catch (BankException e) {
																		// TODO: handle exception
																		System.out.println(e.getMessage());
																	}
																//transaction.showLoanDetails(loans, loanId1);
																break;

															default:
																flag = false;
																System.out.println("please enter valid choice");
																break;
															}
														} catch (InputMismatchException e) {
															flag = false;
															System.out.println("Please enter digits");
														}
													} while (!flag);
													break;

												default:
													choiceFlag1 = false;
													System.out.println("Please enter valid choice");
													break;
												}
											} catch (InputMismatchException e) {
												sc.nextLine();
												choiceFlag1 = false;

												System.out.println("Enter digit only");
											}
										} while (!(choiceFlag1));
										choiceFlag = true;
										break;
									case 3:
										int ch = 0;
										boolean choiceFlag2 = false;
										boolean transFlag=false;
										do {
											try {
												System.out.println("1. deposit 2. withdraw 3. show balance");
												ch = sc.nextInt();
												sc.nextLine();
												choiceFlag2 = true;
												switch (ch) {
												case 1:
													
													do {
													System.out.println("Enter amount to be deposited: ");
													double amount = sc.nextDouble();
													boolean count=false;try {
														transFlag=service.validateamount(amount);
														service.depositAmount(account,amount);
													}catch (BankException e) {
														System.out.println(e.getMessage());
													}
													
														
												}while(!transFlag);
													transFlag=false;
													//transaction.depositAmount(amount, accntId, acc);
													break;
												case 2:do {
													System.out.println("Enter amount to be withdraw: ");
													double withdrawamount = sc.nextDouble();
													try {
													transFlag=service.validateamount(withdrawamount);
													service.withdrawAmount(account,withdrawamount);
													}catch (BankException e) {
														System.out.println(e.getMessage());
													}
												}while(!transFlag);
													transFlag=false;
													//transaction.withDraw(withdrawamount, accntId, acc);
													break;
												case 3:
													//System.out.println(acc1.getDepositeAmmount());
													service.showBalance(accntId);
													break;
												default:
													choiceFlag2 = false;
													System.out.println("Please enter valid choice");
													break;

												}
											} catch (InputMismatchException e) {
												sc.nextLine();
												choiceFlag2 = false;
												System.out.println("Enter digit only");
											}
										} while (!(choiceFlag2));

									}
								} catch (InputMismatchException e) {
									sc.nextLine();
									choiceFlag3 = false;
									System.out.println("Enter digit only");
								}
							} while (!(choiceFlag3));
							choiceFlag = true;
						} catch (BankException e1) {
							System.out.println(e1.getMessage());
						}
						
						

						break;
					default:
						choiceFlag = false;
						System.out.println("Please enter valid choice");
						break;
					}
					System.out.println("Please enter yes to continue: ");
					cont = sc.next();
				} catch (InputMismatchException e) {
					sc.nextLine();
					choiceFlag = false;
					System.out.println("Enter digit only");

				}
			}

			while (!(choiceFlag));

		} while (cont.equalsIgnoreCase("yes"));

	}

}
