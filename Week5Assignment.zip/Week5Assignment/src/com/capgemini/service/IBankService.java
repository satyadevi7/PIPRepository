package com.capgemini.service;

import com.capgemini.bean.Account;
import com.capgemini.bean.Loan;
import com.capgemini.exception.BankException;

public interface IBankService {

	boolean validateName(String accountName)throws BankException;

	String getAccountId()throws BankException;

	boolean validateaccntId(String accntId)throws BankException;

	boolean validateLoan(String loanType)throws BankException;

	boolean addAccount(Account account)throws BankException;

	boolean searchAccount(String accntId)throws BankException;

	boolean getAccount(Account account)throws BankException;

	boolean validateamount(double amount)throws BankException;

	boolean depositAmount(Account account, double amount)throws BankException;

	boolean withdrawAmount(Account account, double withdrawamount)throws BankException;

	boolean showBalance(String accntId)throws BankException;

	boolean addLoan(Account account, Loan loan)throws BankException;

	boolean serachLoan(String loanId)throws BankException;

	boolean payLoan(String loanId1, double loanAmount1)throws BankException;

	boolean getLoan(String loanId)throws BankException;

}
