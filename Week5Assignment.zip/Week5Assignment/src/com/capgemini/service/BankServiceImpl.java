package com.capgemini.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.Account;
import com.capgemini.bean.Loan;
import com.capgemini.dao.BankDAOImpl;
import com.capgemini.dao.IBankDAO;
import com.capgemini.exception.BankException;

public class BankServiceImpl implements IBankService {
	IBankDAO dao= new BankDAOImpl();

	@Override
	public boolean validateName(String accountName) throws BankException {
		boolean flag=false;
		String regex = "[A-Z]{1}[a-zA-Z]{2,}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(accountName);
		if (!m.matches()) {
			throw new BankException("Name must start with a capital letter");
			
		}
		else
			flag=true;
		return flag;
	}

	@Override
	public String getAccountId() throws BankException {
		long accountNo = (long) (Math.random() * 10000000);
		String actId = Long.toString(accountNo);
		actId = actId + "-ASDF";
		return actId;
	}

	@Override
	public boolean validateaccntId(String accntId) throws BankException {
		boolean flag = false;
		String regex = "^[0-9]{7}-ASDF$";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(accntId);
		if (!m.matches()) {
			throw new BankException("Please Enter valid accountId");
			
		} else
			flag= true;
		return flag;
	}

	@Override
	public boolean validateLoan(String loanType) throws BankException {
		if (loanType.equalsIgnoreCase("home") || loanType.equalsIgnoreCase("car")
				|| loanType.equalsIgnoreCase("education"))
			return true;
		else {
			throw new BankException("Please enter correct loan type(car, home, eduaction)");
		}
	}

	@Override
	public boolean addAccount(Account account) throws BankException {
		// TODO Auto-generated method stub
		return dao.addAccount(account);
	}

	@Override
	public boolean searchAccount(String accntId) throws BankException {
		// TODO Auto-generated method stub
		return dao.searchAccount(accntId);
	}

	@Override
	public boolean getAccount(Account account) throws BankException {
		// TODO Auto-generated method stub
		return dao.getAccount(account);
	}

	@Override
	public boolean validateamount(double amount) throws BankException {
		// TODO Auto-generated method stub
		boolean flag= false;
		if(amount<0)
			throw new BankException("amount must be greter than 0");
		else
			flag=true;
		return flag;
	}

	@Override
	public boolean depositAmount(Account account, double amount) throws BankException {
		// TODO Auto-generated method stub
		return dao.depositAmount(account,amount);
	}

	@Override
	public boolean withdrawAmount(Account account, double withdrawamount) throws BankException {
		// TODO Auto-generated method stub
		return dao.withDrawAmount(account,withdrawamount);
	}

	@Override
	public boolean showBalance(String accntId) throws BankException {
		// TODO Auto-generated method stub
		return dao.showBalance(accntId);
	}

	@Override
	public boolean addLoan(Account account, Loan loan) throws BankException {
		// TODO Auto-generated method stub
		return dao.addLoan(account,loan);
	}

	@Override
	public boolean serachLoan(String loanId) throws BankException {
		// TODO Auto-generated method stub
		return dao.searchLoan(loanId);
	}

	@Override
	public boolean payLoan(String loanId1, double loanAmount1) throws BankException {
		// TODO Auto-generated method stub
		return dao.payLoan(loanId1,loanAmount1);
	}

	@Override
	public boolean getLoan(String loanId) throws BankException {
		// TODO Auto-generated method stub
		return dao.getLoan(loanId);
	}
	

}
