package com.capgemini.bean;

public class Transaction extends Loan {
	private double ammount;

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(double ammount) {
		super();
		this.ammount = ammount;
	}

	public double getAmmount() {
		return ammount;
	}

	public void setAmmount(double ammount) {
		this.ammount = ammount;
	}
	public void depositAmount() {
		System.out.println("amount deposited successfully");
	}
	public void withDraw() {
	System.out.println("amount withdrawn successfully");
	}
	public void payLoan() {
	System.out.println("amount paid successfully");
	}
	public void showAccountDetails() {
		new Transaction().getDetails();
	}

}
