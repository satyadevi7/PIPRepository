package com.capgemini.bean;

public class Account {
	private String accountId;
	private String accountName;
	private String address;
	private double depositeAmmount;
	public Account(String accountId, String accountName, String address, double depositeAmmount) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.address = address;
		this.depositeAmmount = depositeAmmount;
	}
	
	public Account(String accountId) {
		super();
		this.accountId = accountId;
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getDepositeAmmount() {
		return depositeAmmount;
	}
	public void setDepositeAmmount(double depositeAmmount) {
		this.depositeAmmount = depositeAmmount;
	}
	public Account getDetails() {
		Account account=new Account();
		account.setAccountId(this.accountId);
		account.setAccountName(this.accountName);
		account.setAddress(this.address);
		account.setDepositeAmmount(depositeAmmount);
		return account;
	}
	public void showDetails() {
		System.out.println( "Account [accountId=" + accountId + ", accountName=" + accountName + ", address=" + address
				+ ", depositeAmmount=" + depositeAmmount + "]");
	}
	
	
	

}
