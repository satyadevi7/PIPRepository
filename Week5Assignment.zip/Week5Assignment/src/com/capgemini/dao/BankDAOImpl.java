package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bean.Account;
import com.capgemini.bean.Loan;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.BankException;
import com.capgemini.utility.DBConnection;

public class BankDAOImpl implements IBankDAO {

	@Override
	public boolean addAccount(Account account) throws BankException {
		// TODO Auto-generated method stub
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int row = -1;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("insert into account values(?,?,?,?)");
			statement.setString(1, account.getAccountId());
			statement.setString(2, account.getAccountName());
			statement.setString(3, account.getAddress());
			statement.setDouble(4, account.getDepositeAmmount());

			row = statement.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return true;
	}

	@Override
	public boolean searchAccount(String accntId) throws BankException {
		// TODO Auto-generated method stub
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int row = -1;
		boolean flag=false;
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select accountName from account where accountId=?");
			statement.setString(1, accntId);
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				flag=true;
				
			}
			else
				throw new BankException("Account Id does not exist");
				
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public boolean getAccount(Account accnt) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		boolean flag=false;
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select accountId,accountName,accountAddress,depositAmount from account where accountId=?");
			statement.setString(1, accnt.getAccountId());
			resultSet=statement.executeQuery();
			while(resultSet.next()) {
				Account account= new Account();
				account.setAccountId(resultSet.getString(1));
				account.setAccountName(resultSet.getString(2));
				account.setAddress(resultSet.getString(3));
				account.setDepositeAmmount(resultSet.getDouble(4));
				account.showDetails();
			}
				
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public boolean depositAmount(Account  account, double amount) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int transactionId = (int) (Math.random() * 10000000);
		
		
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select accountId,accountName,accountAddress,depositAmount from account where accountId=?");
			statement.setString(1, account.getAccountId());
			resultSet=statement.executeQuery();
			resultSet.next();
			double prevamount=resultSet.getDouble(4);
			double amnt=amount+prevamount;
			statement=connection.prepareStatement("update account set depositAmount=? where accountId=?");
			statement.setDouble(1, amnt);
			statement.setString(2, account.getAccountId());
			statement.executeUpdate();
			new Transaction().depositAmount();
			statement = connection.prepareStatement("insert into transaction values(?,?,?,?)");
			statement.setInt(1, transactionId);
			statement.setString(2, account.getAccountId());
			statement.setString(3, "deposit");
			statement.setDouble(4, amount);
			statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

	@Override
	public boolean withDrawAmount(Account account , double withdrawamount) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int transactionId = (int) (Math.random() * 10000000);
		
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select accountId,accountName,accountAddress,depositAmount from account where accountId=?");
			statement.setString(1, account.getAccountId());
			resultSet=statement.executeQuery();
			resultSet.next();
			double prevamount=resultSet.getDouble(4);
			if(prevamount>withdrawamount)
			prevamount=prevamount-withdrawamount;
			else
				throw new BankException("insufficient amount");
			statement=connection.prepareStatement("update account set depositAmount=? where accountId=?");
			statement.setDouble(1, prevamount);
			statement.setString(2, account.getAccountId());
			statement.executeUpdate();
			new Transaction().withDraw();
			statement = connection.prepareStatement("insert into transaction values(?,?,?,?)");
			statement.setInt(1, transactionId);
			statement.setString(2, account.getAccountId());
			statement.setString(3, "withdraw ");
			statement.setDouble(4, withdrawamount);
			statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

	@Override
	public boolean showBalance(String accntId) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int row = -1;
		boolean flag=false;
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select depositAmount from account where accountId=?");
			statement.setString(1, accntId);
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				System.out.println("Balance: "+resultSet.getDouble(1));
				
			}
			else
				throw new BankException("Account Id does not exist");
				
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public boolean addLoan(Account account, Loan loan) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int row = -1;
		try (Connection connection = DBConnection.getConnection();) {

			statement = connection.prepareStatement("insert into loan values(?,?,?,?)");
			statement.setString(1, loan.getLoanId());
			statement.setString(2, account.getAccountId());
			statement.setString(3, loan.getLoanType());
			statement.setDouble(4, loan.getLoanAmmount());

			row = statement.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return true;
	}

	@Override
	public boolean searchLoan(String loanId) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int row = -1;
		boolean flag=false;
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select loanType from loan where loanId=?");
			statement.setString(1, loanId);
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				flag=true;
				
			}
			else
				throw new BankException("loan  does not exist");
				
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public boolean payLoan(String loanId1, double loanAmount1) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int transactionId = (int) (Math.random() * 10000000);
		
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select loanId,accountId,loanType,loanAmount from loan where loanId=?");
			statement.setString(1, loanId1);
			resultSet=statement.executeQuery();
			resultSet.next();
			double prevamount=resultSet.getDouble(4);
			if(prevamount>loanAmount1)
			prevamount=prevamount-loanAmount1;
			else
				throw new BankException("insufficient amount");
			statement=connection.prepareStatement("update loan set loanAmount=? where loanId=?");
			statement.setDouble(1, prevamount);
			statement.setString(2, loanId1);
			statement.executeUpdate();
			
			statement = connection.prepareStatement("insert into transaction values(?,?,?,?)");
			statement.setInt(1, transactionId);
			statement.setString(2, loanId1);
			statement.setString(3, "loan deposit ");
			statement.setDouble(4, loanAmount1);
			statement.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

	@Override
	public boolean getLoan(String loanId) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		boolean flag=false;
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("select loanId,accountId,loanType,loanAmount from loan where loanId=?");
			statement.setString(1, loanId);
			resultSet=statement.executeQuery();
			while(resultSet.next()) {
				Loan loan= new Loan();
				loan.setLoanId(resultSet.getString(1));
				loan.setLoanType(resultSet.getString(3));
				loan.setLoanAmmount(resultSet.getDouble(4));
				loan.showLoanDetails();
			}
				
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public boolean deleteAccount(String accntId) throws BankException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int row = -1;
		boolean flag=false;
		try (Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("delete  from account where accountId=?");
			statement.setString(1, accntId);
			row=statement.executeUpdate();
			System.out.println("deleted successfully");
				
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return flag;
	}

}
