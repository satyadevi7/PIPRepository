package com.capgemini.dao;

import com.capgemini.bean.Account;
import com.capgemini.bean.Loan;
import com.capgemini.exception.BankException;

public interface IBankDAO {

	boolean addAccount(Account account)throws BankException;

	boolean searchAccount(String accntId)throws BankException;

	boolean getAccount(Account account)throws BankException;

	boolean depositAmount(Account account, double amount)throws BankException;

	boolean withDrawAmount(Account account, double withdrawamount)throws BankException;

	boolean showBalance(String accntId)throws BankException;

	boolean addLoan(Account account, Loan loan)throws BankException;

	boolean searchLoan(String loanId)throws BankException;

	boolean payLoan(String loanId1, double loanAmount1)throws BankException;

	boolean getLoan(String loanId)throws BankException;

	boolean deleteAccount(String accntId)throws BankException;

}
