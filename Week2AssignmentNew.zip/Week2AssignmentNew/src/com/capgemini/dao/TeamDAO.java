package com.capgemini.dao;

import com.capgemini.beans.Player;

public interface TeamDAO {

	Player createPlayer(String player);

	boolean createTeam(String team1);

	boolean createMatch(String match);

	boolean findTeam(String date);

	boolean findallMatchesofTeam(String teamName);

}
