package com.capgemini.dao;

import com.capgemini.beans.Match;
import com.capgemini.beans.MatchBO;
import com.capgemini.beans.Player;
import com.capgemini.beans.PlayerBO;
import com.capgemini.beans.Team;
import com.capgemini.beans.TeamBO;
import com.capgemini.exception.TeamException;

public class TeamDAOImpl implements TeamDAO {
	static Player[] playerList = new Player[10];
	static Team[] teamList = new Team[10];
	static Match[] matchList = new Match[10];
	int i = 0, j = 0, k = 0;

	@Override
	public Player createPlayer(String player) {
		// TODO Auto-generated method stub
		PlayerBO play = new PlayerBO();
		Player player1 = null;
		try {
			player1 = play.createPlayer(player);
			if (i < playerList.length) {
				playerList[i] = player1;
				i++;
			}
		} catch (TeamException e) {
			System.out.println(e.getMessage());
		}

		/*
		 * for (Player player2 : playerList) { System.out.println(player2); }
		 */
		return player1;
	}

	@Override
	public boolean createTeam(String team1) {
		// TODO Auto-generated method stub
		TeamBO team = new TeamBO();
		boolean flag = false;
		Team team2 = null;
		try {
			team2 = team.createTeam(team1, playerList);
			flag = true;
			if (j < teamList.length) {
				teamList[j] = team2;
				j++;
			}
		} catch (TeamException e) {
			flag = false;
			System.out.println(e.getMessage());
		}

		/*
		 * for (Team team3 : teamList) { System.out.println(team3); }
		 */
		return flag;
	}

	@Override
	public boolean createMatch(String match) {
		// TODO Auto-generated method stub
		MatchBO match1 = new MatchBO();
		boolean flag = false;
		Match match2 = null;
		try {
			match2 = match1.createMatch(match, teamList);
			flag = true;
			if (k < matchList.length) {
				matchList[k] = match2;
				k++;
			}
		} catch (TeamException e) {
			// TODO Auto-generated catch block
			flag = false;
			System.out.println(e.getMessage());
		}

		/*
		 * for (Match match3 : matchList) { System.out.println(match3); }
		 */
		return flag;
	}

	@Override
	public boolean findTeam(String date) {
		// TODO Auto-generated method stub
		MatchBO match1 = new MatchBO();

		// Team[] teams=null;
		try {
			Team[] teams = match1.findTeam(date, matchList);
			//
			// match1.getTeams();
			System.out.println("Team");
			for (Team team : teams) {
				if (team == null)
					continue;
				else
					System.out.print(team.getName() + " ");
			}
		} catch (TeamException e) {
			System.out.println(e.getMessage());
		}

		return true;
	}

	@Override
	public boolean findallMatchesofTeam(String teamName) {
		// TODO Auto-generated method stub
		MatchBO match1 = new MatchBO();
		boolean flag = false;
		try {
			match1.findAllMatchesofTeam(teamName, matchList);
		} catch (TeamException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

}
