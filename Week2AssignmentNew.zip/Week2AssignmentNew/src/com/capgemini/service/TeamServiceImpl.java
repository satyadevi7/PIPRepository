package com.capgemini.service;

import com.capgemini.beans.Player;
import com.capgemini.dao.TeamDAO;
import com.capgemini.dao.TeamDAOImpl;

public class TeamServiceImpl implements TeamService {
	static TeamDAO dao = new TeamDAOImpl();

	@Override
	public Player createPlayer(String player) {
		// TODO Auto-generated method stub
		return dao.createPlayer(player);
	}

	@Override
	public boolean createTeam(String team1) {
		// TODO Auto-generated method stub
		return dao.createTeam(team1);
	}

	@Override
	public boolean createMatch(String match) {
		// TODO Auto-generated method stub
		return dao.createMatch(match);
	}

	@Override
	public boolean findTeam(String date) {
		// TODO Auto-generated method stub
		return dao.findTeam(date);
	}

	@Override
	public boolean findallMatchesofTeam(String teamName) {
		// TODO Auto-generated method stub
		return dao.findallMatchesofTeam(teamName);
	}

}
