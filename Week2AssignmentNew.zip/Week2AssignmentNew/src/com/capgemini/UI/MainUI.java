package com.capgemini.UI;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.beans.Player;
import com.capgemini.beans.Team;
import com.capgemini.service.TeamService;
import com.capgemini.service.TeamServiceImpl;

public class MainUI {
	public static Scanner sc = new Scanner(System.in);
	static TeamService service = new TeamServiceImpl();

	public static void main(String[] args) {
		System.out.println("Welcome");
		Player player = null;
		boolean teamFlag = false;
		boolean matchFlag = false;
		boolean flag = false;
		do {
			try {
				System.out.println("Enter the player Count: ");
				int n = sc.nextInt();
				sc.nextLine();
				flag = true;

				// int i=0;

				for (int i = 0; i < n; i++) {
					do {
						System.out.println("Enter Player " + (i + 1) + " details");
						String player1 = sc.nextLine();
						player = service.createPlayer(player1);

					} while (player == null);
				}
			} catch (InputMismatchException e) {
				sc.nextLine();
				System.out.println("Please Enter digits only");
				flag = false;
			}
		} while (!flag);
		flag = false;
		do {
			try {

				System.out.println("Enter the team count");
				int teamCount = sc.nextInt();
				flag = true;
				sc.nextLine();
				for (int i = 0; i < teamCount; i++) {
					do {
						System.out.println("Enter Team " + (i + 1) + " details");
						String team1 = sc.nextLine();
						teamFlag = service.createTeam(team1);
					} while (!teamFlag);
				}
			} catch (InputMismatchException e) {
				sc.nextLine();
				System.out.println("Please Enter digits only");
				flag = false;
			}
		} while (!flag);
		flag = false;
		do {
			try {
				System.out.println("Enter match count: ");
				int matchCount = sc.nextInt();
				flag = true;
				sc.nextLine();
				for (int i = 0; i < matchCount; i++) {
					do {
						System.out.println("Enter match " + (i + 1) + " details");
						String match = sc.nextLine();
						matchFlag = service.createMatch(match);
					} while (!matchFlag);

				}
			} catch (InputMismatchException e) {
				sc.nextLine();
				System.out.println("Please Enter digits only");
				flag = false;
			}
		} while (!flag);
		boolean flag1 = false;
		do {
			System.out.println("Menu: ");
			System.out.println("1) Find Team");
			System.out.println("2) Find all matches in a specific venue");

			try {
				System.out.println("Enter choice: ");
				int choice = sc.nextInt();
				sc.nextLine();
				flag = true;
				switch (choice) {
				case 1:
					System.out.println("Enter match date");
					String date = sc.next();

					service.findTeam(date);
					break;
				case 2:
					System.out.println("match Details: ");
					System.out.println("Enter team Name");
					String teamName = sc.next();
					service.findallMatchesofTeam(teamName);
					break;

				default:
					System.out.println("Enter 1 or 2");
					flag1 = false;
					break;
				}
				System.out.println("do you want to continue yes/no");
				String continue1 = sc.next();
				if (continue1.equalsIgnoreCase("yes"))
					flag1 = false;
				else if (continue1.equalsIgnoreCase("no"))
					System.exit(0);

			} catch (InputMismatchException e) {
				flag1 = false;
				sc.nextLine();
				System.out.println("enter digits only");
			}
		} while (!flag1);

	}

}
