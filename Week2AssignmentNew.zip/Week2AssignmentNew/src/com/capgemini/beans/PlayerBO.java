package com.capgemini.beans;

import com.capgemini.exception.TeamException;

public class PlayerBO extends Player {
	public Player createPlayer(String data) throws TeamException {
		Player player = null;
		String[] player1 = data.split("[,]", 3);
		if (player1.length == 3) {
			player = new Player(player1[0], player1[1], player1[2]);
		} else {
			throw new TeamException("Please Enter valid player details in format: " + "Name,Country,Skill");
		}
		// System.out.println(player);
		return player;
	}

}
