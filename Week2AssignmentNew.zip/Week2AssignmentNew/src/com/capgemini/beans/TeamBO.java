package com.capgemini.beans;

import com.capgemini.exception.TeamException;

public class TeamBO extends Team {
	public Team createTeam(String data, Player[] playerList) throws TeamException {
		String[] player = data.split(",");
		Player main = new Player();
		String nameofTeam = null;
		String name = null;
		boolean flag = false;
		if (player.length == 2) {
			nameofTeam = player[0];
			name = player[1];
		} else {
			throw new TeamException("Please enter valid team details in format: " + "Name of team,Name of player");
		}
		for (Player player1 : playerList) {
			if (player1 == null)
				continue;
			else if (name.equalsIgnoreCase(player1.getName())) {
				flag = true;
				main = player1;
			}
		}
		if (flag)
			return new Team(nameofTeam, main);
		else
			throw new TeamException("Player not present");
	}

}
