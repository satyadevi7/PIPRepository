package com.capgemini.beans;

import com.capgemini.exception.TeamException;

public class MatchBO extends Match {
	public Match createMatch(String data, Team[] teamList) throws TeamException {
		String[] str = data.split(",");
		boolean flag = false, flag1 = false;
		String date = null, teamOne = null, teamTwo = null, venue = null;
		Team team1 = null;
		Team team2 = null;
		if (str.length == 4) {
			date = str[0];
			teamOne = str[1];
			teamTwo = str[2];
			venue = str[3];
		} else {
			throw new TeamException("Please Enter valid match details in format: " + "Date,Team one,Team two,Venue");
		}
		for (int i = 0; i < teamList.length; i++) {
			if (teamList[i] == null)
				continue;
			else if (teamList[i].getName().equalsIgnoreCase(teamOne)) {
				flag = true;
				team1 = teamList[i];
			}

		}
		for (Team team : teamList) {
			if (team == null)
				continue;
			else if (team.getName().equalsIgnoreCase(teamTwo)) {
				flag1 = true;

				team2 = team;
			}
		}
		if (flag && flag1) {
			Team[] teams = new Team[10];
			teams[0] = team1;
			teams[1] = team2;
			Match match = new Match(date, team1, team2, venue, teams);
			return match;
		} else {
			throw new TeamException("Team not present");
		}
	}

	public Team[] findTeam(String matchDate, Match[] matchList) throws TeamException {
		Team[] teams = null;
		boolean flag = false;
		//System.out.println(matchDate);
		for (Match match : matchList) {

			if (match != null) {

				if (match.getDate().equals(matchDate)) {
					//System.out.println(match.getDate());
					flag = true;
					teams = match.getTeams();
				} else {
					flag = false;
				}
			}

		}
		if (!flag) {
			throw new TeamException("Not found");
		}
		return teams;
	}

	public void findAllMatchesofTeam(String teamName, Match[] matchList) throws TeamException {
		boolean flag = false;

		for (Match match : matchList) {
			if (match == null)
				continue;

			else if (match.getTeamOne().getName().equalsIgnoreCase(teamName)
					|| match.getTeamTwo().getName().equalsIgnoreCase(teamName)) {
				flag = true;
				System.out.println(match);
			} else {
				flag = false;
			}
		}
		if (!flag)
			throw new TeamException("Invalid team name");
	}

}
