package com.capgemini.beans;

public class Match {
	private String date;
	private Team teamOne;
	private Team teamTwo;
	private String venue;
	private Team[] teams=new Team[2];
	public Match(String date, Team teamOne, Team teamTwo, String venue, Team[] teams) {
		super();
		this.date = date;
		this.teamOne = teamOne;
		this.teamTwo = teamTwo;
		this.venue = venue;
		this.teams = teams;
	}
	public Match() {
		// TODO Auto-generated constructor stub
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Team getTeamOne() {
		return teamOne;
	}
	public void setTeamOne(Team teamOne) {
		this.teamOne = teamOne;
	}
	public Team getTeamTwo() {
		return teamTwo;
	}
	public void setTeamTwo(Team teamTwo) {
		this.teamTwo = teamTwo;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public Team[] getTeams() {
		return teams;
	}
	public void setTeams(Team[] teams) {
		this.teams = teams;
	}
	@Override
	public String toString() {
		String str=String.format("%-15s%-15s%-15s%-15s", date,teamOne.getName(),teamTwo.getName(),venue);
		return  str;
	}
	

}
