package com.capgemini.exception;

public class TeamException extends Exception {

	public TeamException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
