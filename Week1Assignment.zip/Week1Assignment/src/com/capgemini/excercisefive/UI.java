package com.capgemini.excercisefive;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UI {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Account[] acc= new Account[10];
		Loan[] loans= new Loan[10];
		Transaction transaction= new Transaction();
		Loan loan= new Loan();
	
		int choice=0;
		String cont=null;
		do {
		do {
		System.out.println("1. Create Account 2. Login");
		 choice=sc.nextInt();
		//sc.nextLine();
		switch (choice) {
		case 1:
			//Scanner sc = new Scanner(System.in);
			String accountName=null;
			String accountId=null;
			
			int i=0;
			do {
				System.out.println("Account Name: ");
			 accountName=sc.next();
			}
			while(!validateName(accountName));
			System.out.println("Address: ");
			String address=sc.next();
			System.out.println("Enter deposit ammount: ");
			double depositAmount=sc.nextDouble();
			String loanType=null;
			double loanAmount=0;
			String choice1=null;
			/*
			 * do { System.out.println("Do u want Loan :(Yes or No)"); choice1=sc.next();
			 * if(choice1.equalsIgnoreCase("yes")) { do {
			 * System.out.println("Enter loan type: "); loanType=sc.next();
			 * }while(validateLoan(loanType)); System.out.println("Enter loan amount: ");
			 * loanAmount=sc.nextDouble(); String loanId=getAccountId();
			 * 
			 * }else { System.out.println("Plase enter yes or no"); }}
			 * while(choice1.equalsIgnoreCase("yes")||choice1.equalsIgnoreCase("no"));
			 */
			accountId=getAccountId();
			for(i=0;i<10;i++) {
				acc[i]=new Account(accountId,accountName,address,depositAmount);
			}
			System.out.println("Account created successfully with accountId: "+accountId);
			
			break;
		case 2:
			String accntId=null;
			int choice2=0;
			Account acc1=null;
			do {
				
			System.out.println("Enter accountId: ");
			
			 accntId=sc.next();
			}while(!validateaccntId(accntId));
			for(int j=0;j<10;j++) {
				if(accntId.equals(acc[j].getAccountId())) {
					acc1=acc[j];}
				
					else{
						System.out.println("Account does not exist");
						break;
						}
					}
			
			do {
			System.out.println("1. Account Details 2. Loan 3. Transaction");
			choice2=sc.nextInt();
			switch (choice2) {
			case 1:
				transaction.showDetails(acc1);
				
				break;
			case 2:
				int ch1=0;
				do {
					System.out.println("1. Apply Loan 2. Pay loan 3. Loan details");
					ch1=sc.nextInt();
					Loan loan1=null;
					switch (ch1) {
					case 1:do {
						System.out.println("Enter loan type: "); 
						loanType=sc.next();
						 }while(validateLoan(loanType));
					System.out.println("Enter loan amount: ");
						  loanAmount=sc.nextDouble(); 
						  String loanId=getAccountId();
						  System.out.println("Loan Created with loan Id: "+loanId);
						  for (int j = 0; j < loans.length; j++) {
							loans[j]=new Loan(loanId,loanType,loanAmount);
						}
						break;

					case 2:String loanId1=null;
						do {
						System.out.println("Enter loan Id");
						 loanId1=sc.next();
					}while(!validateaccntId(loanId1));
						
						for(int j=0;j<10;j++) {
							if(loanId1.equals(loans[j].getLoanId())) {
								loan1=loans[j];}
							
								else{
									System.out.println("Account does not exist");
									break;
									}
								}
						System.out.println("Enter amount: ");
						double loanAmount1=sc.nextDouble();
						transaction.payLoan(loanAmount1, loanId1, loans);
						break;
					case 3:
						transaction.showLoanDetails(loan1);
						break;
					default:
						break;
					}
				} while (!(ch1<=1&&ch1>=3));
				
				break;
			case 3:int ch=0;
				do {
					System.out.println("1. deposit 2. withdraw 3. show balance");
				 ch=sc.nextInt();
			
				
				switch (ch) {
				case 1:
					System.out.println("Enter amount to be deposited: ");
					double amount=sc.nextDouble();
					transaction.depositAmount(amount, accntId, acc);
					
					break;
				case 2:
					System.out.println("Enter amount to be withdraw: ");
					double withdrawamount=sc.nextDouble();
					transaction.withDraw(withdrawamount, accntId, acc);
					
					break;
				case 3:
					System.out.println(acc1.getDepositeAmmount());
					break;

				
				}
			}while(!(ch>=1&&ch<=3));
				

			
			}
			}while(!(choice>=1&&choice<=3));
			
		
		

		
		}
		System.out.println("Please enter yes to continue: ");
		cont=sc.next();}
		
		while(!(choice>=1&&choice<=2));
		
		
		}while(cont.equalsIgnoreCase("yes"));

	}

	private static boolean validateaccntId(String accntId) {
		// TODO Auto-generated method stub
		boolean flag= false;
		String regex="^[0-9]{7}-ASDF$";
			Pattern p= Pattern.compile(regex);
			Matcher m= p.matcher(accntId);
			if(!m.matches())
			{
			System.out.println("Please Enter valid accountId");
			return false;
			}
			else
		return true;
	}

	private static String getAccountId() {
		// TODO Auto-generated method stub
		long accountNo=(long)(Math.random()*10000000);
		String actId=Long.toString(accountNo);
		actId=actId+"-ASDF";
		return actId;
	}

	private static boolean validateLoan(String loanType) {
		// TODO Auto-generated method stub
		if (loanType.equalsIgnoreCase("home") || loanType.equalsIgnoreCase("car")
				|| loanType.equalsIgnoreCase("education"))
			return true;
		else {
			System.out.println("Please enter correct loan type(car, home, eduaction)");
			return false;
		}
	}

	private static boolean validateName(String accountName) {
		// TODO Auto-generated method stub

		String regex = "[A-Z]{1}[a-zA-Z]{2,}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(accountName);
		if (!m.matches()) {
			System.out.println("Name must start with a capital letter");
			return false;
		}
		return true;

	}

}
