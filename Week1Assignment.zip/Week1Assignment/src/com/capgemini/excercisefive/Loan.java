package com.capgemini.excercisefive;

public class Loan extends Account {
	private String loanId;
	private String loanType;
	private double loanAmmount;
	public Loan(String loanId, String loanType, double loanAmmount) {
		super();
		this.loanId = loanId;
		this.loanType = loanType;
		this.loanAmmount = loanAmmount;
	}
	public Loan() {
		// TODO Auto-generated constructor stub
	}
	public String getLoanId() {
		return loanId;
	}
	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public double getLoanAmmount() {
		return loanAmmount;
	}
	public void setLoanAmmount(double loanAmmount) {
		this.loanAmmount = loanAmmount;
	}
	public void getLoan() {
		
	}
	public void showLoanDetails(Loan loan) {
		System.out.println(loan.loanId);
		System.out.println(loan.loanType);
		System.out.println(loan.loanAmmount);
	}

}
