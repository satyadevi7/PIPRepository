package com.capgemini.excercisefive;

public class Account {
	private String accountId;
	private String accountName;
	private String address;
	private double depositeAmmount;
	public Account(String accountId, String accountName, String address, double depositeAmmount) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.address = address;
		this.depositeAmmount = depositeAmmount;
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getDepositeAmmount() {
		return depositeAmmount;
	}
	public void setDepositeAmmount(double depositeAmmount) {
		this.depositeAmmount = depositeAmmount;
	}
	public void getDetails() {
	}
	public void showDetails(Account acc) {
		System.out.println(acc.getAccountId());
		System.out.println(acc.getAccountName());
		System.out.println(acc.getAddress());
		System.out.println(acc.getDepositeAmmount());
	}
	

}
